---
title: The Crew
weight: 2
sidebar:
  open: true
---

👩‍🎓 A number of people have contributed to the development and maintenance of ***pipesnake***. In no particular order: