---
title: Shortcodes
---

Build the best docs with re-usable components, referred to as Hugo shortcodes:

{{< cards >}}
  {{< card url="callout" title="Callout" icon="warning" >}}
  {{< card url="cards" title="Cards" icon="card" >}}
  {{< card url="toggle" title="Spoiler" icon="chevron-right" >}}
  {{< card url="steps" title="Steps" icon="one" >}}
{{< /cards >}}
