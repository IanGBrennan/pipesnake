---
title: Getting Started
weight: 2
sidebar:
  open: true
---

{{< cards >}}
  {{< card url="project-structure" title="Project Structure" icon="document-duplicate" >}}
  {{< card url="configuration" title="Configuration" icon="adjustments-vertical" >}}
{{< /cards >}}
